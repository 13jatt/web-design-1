Alpha Version: Implemented layout and included various libraries to make the app more interactive, Added video on the background of all pages

Beta Version: Change layout, Added animation and added logo image

Final Version: Removed video from all pages excluding homepage, Implemented Responsiveness Design