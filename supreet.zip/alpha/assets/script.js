$(document).ready(function(){
    $('.slider').slick({
      autoplay: true,
      prevArrow:false,
      nextArrow:false,
      dots:true
    });
  });